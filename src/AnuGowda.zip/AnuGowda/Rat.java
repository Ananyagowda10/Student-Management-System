package AnuGowda;
import java.util.*;
public class Rat {

	public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	int rat=sc.nextInt();
	int unit=sc.nextInt();
	int n=sc.nextInt();
	int[] arr=new int[n];
	for(int i=0;i<n;i++)
	{
		arr[i]=sc.nextInt();
	}
	FindFood(arr,rat,unit,n);
	

	}
	public static int FindFood(int[] arr,int rat,int unit,int n)
	{
		
		int rats=rat*unit,sum=0;
		for(int i=0;i<n;i++) {
		if(arr.length==0 || arr==null)
		{
			return -1;
		}else if(sum>rats)
		{
			sum=sum-rats;
			return sum;
		}else
		{
			sum=sum+arr[i];
		}
	}

	}}
